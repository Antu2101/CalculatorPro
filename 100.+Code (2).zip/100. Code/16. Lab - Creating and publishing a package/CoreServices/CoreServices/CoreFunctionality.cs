﻿namespace CoreServices
{
    public class CoreFunctionality
    {
        public String Display()
        {
            return "This class has core functionality";
        }
    }
}